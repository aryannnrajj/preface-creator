import React, { useState, useCallback } from 'react';
import PrefaceForm from './components/PrefaceForm';
import PrefacePreview from './components/PrefacePreview';
import { generatePrefaceText } from './services/geminiService';
import { SCHOOL_LOGO_BASE64 } from './constants';
import type { FormData, CustomizationData } from './types';

const App: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    studentName: 'Aryan Raj Singh',
    projectTitle: 'Consumer Rights',
    schoolName: 'Rainbow Public School, Chira Chas, Bokaro',
    className: '10',
  });

  const [customization, setCustomization] = useState<CustomizationData>({
    font: 'font-merriweather',
    template: 'classic',
  });

  const [preface, setPreface] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setPreface('');
    try {
      const generatedText = await generatePrefaceText(formData, customization);
      setPreface(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [formData, customization]);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="bg-white shadow-md print:hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src={SCHOOL_LOGO_BASE64} alt="School Logo" className="h-12 w-12" />
            <h1 className="text-xl md:text-2xl font-bold text-slate-700 font-playfair">
              Aryan Papa - Preface Generator
            </h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4 print:hidden">
            <PrefaceForm
              formData={formData}
              setFormData={setFormData}
              customization={customization}
              setCustomization={setCustomization}
              onGenerate={handleGenerate}
              isLoading={isLoading}
            />
          </div>
          <div className="lg:col-span-8">
            <PrefacePreview
              formData={formData}
              preface={preface}
              customization={customization}
              isLoading={isLoading}
              error={error}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;