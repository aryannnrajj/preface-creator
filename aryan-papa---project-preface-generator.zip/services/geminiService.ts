import { GoogleGenAI } from "@google/genai";
import type { FormData, CustomizationData } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generatePrefaceText = async (formData: FormData, customization: CustomizationData): Promise<string> => {
  const { studentName, projectTitle, schoolName, className } = formData;
  const { template } = customization;

  const prompt = `
    Generate a professional, awesome, and heartfelt preface for a class ${className} school project.
    The desired tone should reflect a '${template}' style. For example, 'classic' is formal and traditional, 'modern' is clean and direct, and 'minimalist' is concise and to the point.

    **Project Details:**
    - **Student Name:** ${studentName}
    - **Project Title:** "${projectTitle}"
    - **School Name:** ${schoolName}
    - **Class:** ${className}

    **Instructions:**
    1.  Start with an appropriate title like "Preface" or "Acknowledgement".
    2.  The preface must be structured into a few well-written paragraphs.
    3.  **First Paragraph:** Introduce the project topic "${projectTitle}" and briefly state its importance and objectives. Mention that this project is a part of the class ${className} curriculum.
    4.  **Second Paragraph (Acknowledgement):** Express sincere gratitude towards the subject teacher (use a generic placeholder like "my respected subject teacher"), the school principal, and the school (${schoolName}) for providing the opportunity and guidance.
    5.  **Third Paragraph:** Thank parents, family, and friends for their continuous support and encouragement throughout the project.
    6.  **Concluding Sentence:** Conclude with a hopeful note about the project's learning experience and the knowledge gained.
    7.  End with the student's name, "${studentName}".

    The output should be high-quality, grammatically correct, and formatted as plain text with paragraph breaks. Do not use markdown.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error generating preface:", error);
    throw new Error("Failed to generate preface. Please check your API key and try again.");
  }
};