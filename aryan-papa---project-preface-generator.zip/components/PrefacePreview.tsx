import React from 'react';
import { SCHOOL_LOGO_BASE64 } from '../constants';
import Spinner from './Spinner';
import type { FormData, CustomizationData } from '../types';

interface PrefacePreviewProps {
  formData: FormData;
  preface: string;
  customization: CustomizationData;
  isLoading: boolean;
  error: string | null;
}

const PrefacePreview: React.FC<PrefacePreviewProps> = ({ formData, preface, customization, isLoading, error }) => {
  
  const handlePrint = () => {
    window.print();
  };

  const templateBaseClass = "bg-white shadow-lg rounded-lg min-h-[500px] transition-all duration-300";

  const templateStyles = {
    classic: 'border-double border-8 border-slate-700 p-12 md:p-16',
    modern: 'p-8 sm:p-12 md:p-16 border-l-8 border-indigo-500',
    minimalist: 'p-8 sm:p-12 md:p-16',
  };
  
  const fontClass = customization.font;

  const fullClassName = `${templateBaseClass} ${templateStyles[customization.template]} ${fontClass}`;

  const renderHeader = () => {
    switch (customization.template) {
        case 'classic':
            return (
                <header className="text-center mb-12">
                    {customization.template !== 'minimalist' && <img src={SCHOOL_LOGO_BASE64} alt="School Logo" className="h-24 w-24 mx-auto mb-4" />}
                    <h1 className="text-3xl font-bold font-playfair text-gray-800">{formData.schoolName}</h1>
                    <hr className="my-4 border-t-2 border-gray-300 w-1/4 mx-auto" />
                    <h2 className="text-2xl font-semibold text-gray-700 mt-2">Project: {formData.projectTitle}</h2>
                </header>
            );
        case 'modern':
             return (
                <header className="mb-10 text-left">
                    {customization.template !== 'minimalist' && <img src={SCHOOL_LOGO_BASE64} alt="School Logo" className="h-20 w-20 mb-4" />}
                    <h2 className="text-xl font-bold text-gray-500 uppercase tracking-wider">{formData.schoolName}</h2>
                    <h1 className="text-4xl font-bold text-gray-800 mt-1">{formData.projectTitle}</h1>
                </header>
             );
        case 'minimalist':
            return (
                <header className="mb-10 text-left">
                     <h1 className="text-3xl font-bold text-gray-800">{formData.projectTitle}</h1>
                     <h2 className="text-lg font-normal text-gray-500">{formData.schoolName}</h2>
                </header>
            )
        default:
            return null;
    }
  }


  return (
    <div className="relative">
      <div id="print-area" className={fullClassName}>
        {isLoading && (
          <div className="absolute inset-0 bg-white bg-opacity-75 flex flex-col items-center justify-center rounded-lg z-10">
            <Spinner />
            <p className="mt-4 text-slate-600 font-medium">Generating your preface...</p>
          </div>
        )}

        {error && !isLoading && (
           <div className="flex flex-col items-center justify-center h-full text-center">
             <div className="text-red-500 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
             </div>
             <h3 className="text-lg font-semibold text-red-700">Generation Failed</h3>
             <p className="text-slate-600 mt-2">{error}</p>
           </div>
        )}

        {!isLoading && !error && (
          <>
            {renderHeader()}
            
            <main className="text-gray-700 leading-relaxed space-y-4 whitespace-pre-wrap text-justify">
              {preface ? (
                <p>{preface}</p>
              ) : (
                <div className="text-center text-slate-500 py-16">
                  <p>Your generated preface will appear here.</p>
                  <p className="text-sm">Fill in the details and click "Generate Preface".</p>
                </div>
              )}
            </main>

            {preface && (
              <footer className="mt-16 text-right">
                <p className="font-semibold">{formData.studentName}</p>
                <p>Class {formData.className}</p>
              </footer>
            )}
          </>
        )}
      </div>
      
      {preface && !isLoading && !error && (
        <button 
          onClick={handlePrint} 
          className="print:hidden absolute top-4 right-4 bg-indigo-600 text-white p-2 rounded-full shadow-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform hover:scale-110"
          title="Print or Save as PDF"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm2-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
          </svg>
        </button>
      )}
    </div>
  );
};

export default PrefacePreview;