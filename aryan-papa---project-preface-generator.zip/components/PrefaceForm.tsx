import React from 'react';
import type { FormData, CustomizationData, FontStyle, DesignTemplate } from '../types';

interface PrefaceFormProps {
  formData: FormData;
  setFormData: React.Dispatch<React.SetStateAction<FormData>>;
  customization: CustomizationData;
  setCustomization: React.Dispatch<React.SetStateAction<CustomizationData>>;
  onGenerate: () => void;
  isLoading: boolean;
}

const InputField: React.FC<{ label: string; id: keyof FormData; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; }> = ({ label, id, value, onChange }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-600 mb-1">
            {label}
        </label>
        <input
            type="text"
            id={id}
            name={id}
            value={value}
            onChange={onChange}
            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
        />
    </div>
);

const PrefaceForm: React.FC<PrefaceFormProps> = ({ formData, setFormData, customization, setCustomization, onGenerate, isLoading }) => {
    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCustomizationChange = <K extends keyof CustomizationData>(key: K, value: CustomizationData[K]) => {
        setCustomization(prev => ({ ...prev, [key]: value }));
    };

    const designOptions: {id: DesignTemplate, label: string}[] = [
        { id: 'classic', label: 'Classic' },
        { id: 'modern', label: 'Modern' },
        { id: 'minimalist', label: 'Minimalist' },
    ];

    const fontOptions: {id: FontStyle, label: string}[] = [
        { id: 'font-merriweather', label: 'Serif (Merriweather)' },
        { id: 'font-lato', label: 'Sans-Serif (Lato)' },
        { id: 'font-roboto-slab', label: 'Slab (Roboto Slab)' },
    ];

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-bold mb-4 font-playfair text-slate-700">Project Details</h2>
                <div className="space-y-4">
                    <InputField label="Student Name" id="studentName" value={formData.studentName} onChange={handleFormChange} />
                    <InputField label="Project Title" id="projectTitle" value={formData.projectTitle} onChange={handleFormChange} />
                    <InputField label="School Name" id="schoolName" value={formData.schoolName} onChange={handleFormChange} />
                    <InputField label="Class" id="className" value={formData.className} onChange={handleFormChange} />
                </div>
            </div>

             <div className="bg-white p-6 rounded-lg shadow-lg">
                <h2 className="text-xl font-bold mb-4 font-playfair text-slate-700">Design & Style</h2>
                <div className="space-y-4">
                   <div>
                       <label className="block text-sm font-medium text-slate-600 mb-2">Template</label>
                       <div className="flex space-x-2 rounded-md bg-slate-100 p-1">
                           {designOptions.map(opt => (
                               <button 
                                key={opt.id} 
                                onClick={() => handleCustomizationChange('template', opt.id)}
                                className={`w-full text-center px-3 py-1.5 text-sm font-semibold rounded-md transition-colors ${customization.template === opt.id ? 'bg-indigo-600 text-white shadow' : 'text-slate-600 hover:bg-slate-200'}`}>
                                   {opt.label}
                               </button>
                           ))}
                       </div>
                   </div>
                   <div>
                       <label htmlFor="font" className="block text-sm font-medium text-slate-600 mb-1">Font Style</label>
                       <select 
                        id="font" 
                        value={customization.font} 
                        onChange={(e) => handleCustomizationChange('font', e.target.value as FontStyle)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                       >
                           {fontOptions.map(opt => (
                               <option key={opt.id} value={opt.id}>{opt.label}</option>
                           ))}
                       </select>
                   </div>
                </div>
            </div>

            <button
                onClick={onGenerate}
                disabled={isLoading}
                className="w-full bg-indigo-600 text-white font-semibold py-3 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors duration-300 flex items-center justify-center text-base"
            >
                {isLoading ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Generating...
                    </>
                ) : (
                    '✨ Generate Preface ✨'
                )}
            </button>
        </div>
    );
};

export default PrefaceForm;