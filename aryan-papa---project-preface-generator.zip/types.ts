export interface FormData {
  studentName: string;
  projectTitle: string;
  schoolName: string;
  className: string;
}

export type FontStyle = 'font-merriweather' | 'font-lato' | 'font-roboto-slab';
export type DesignTemplate = 'classic' | 'modern' | 'minimalist';

export interface CustomizationData {
  font: FontStyle;
  template: DesignTemplate;
}
